using Authors.Models;
using Library.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Library.Services;

namespace Library.Services;
public class AuthorRepository : IAuthorRepository
{
    private readonly LibraryContext _context;
    public AuthorRepository(LibraryContext context)

    {
        _context = context;
    }

//LISTAR TODOS LOS USUARIOS
    
    public IEnumerable<Author> GetAll()
    {
        return _context.Authors.ToList();
    }


}