using Microsoft.AspNetCore.Mvc;

using Authors.Models;

namespace Library.Services
{
    public interface IAuthorRepository
    {
      IEnumerable<Author> GetAll();//Listar todos los autores
    }
}
    