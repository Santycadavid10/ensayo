using Authors.Models;
using Microsoft.AspNetCore.Mvc;
using Library.Services;

public class ViewsAuthorsnController : ControllerBase
{
  private readonly IAuthorRepository _authorRepository;

  public ViewsAuthorsnController(IAuthorRepository authorRepository)
  {
    _authorRepository = authorRepository;
  }



  //Listar Authores
  [HttpGet]
  [Route("Listar")]
  public IEnumerable<Author> GetCoupons()
  {
    return _authorRepository.GetAll();
  }


  

//listar Atuthor por ID detalles
}