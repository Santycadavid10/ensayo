using Coupons.Models;
using LUEGOPAGO.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CouponsRepository;
    [Route("api/[controller]")]
    [ApiController]
    public class CouponRepository : ICouponRepository
    {
        
        private readonly LuegoPagoContext _context;
        public CouponRepository(LuegoPagoContext context)

        {
            _context = context;
        }

        [HttpGet]
        public IEnumerable<Coupon> GetAll()
        {
            return _context.Coupons.ToList();
        }
    }