using Coupons.Models;
    public interface ICouponRepository
    {
         IEnumerable<Coupon> GetAll();



    }
