

using System.ComponentModel.DataAnnotations.Schema;//utilizo para habilitar [NotMapped] qqe abajo se utilizara para no mapiar imagen en bd

namespace Coupons.Models;

public class Coupon
{
    public int Id { get; set; }
    public string? Name { get; set; }
    public double ValueCoupon { get; set; }
    public string? Stores { get; set; }
    public string? StatusCoupon { get; set; }
    public string? Type { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndingDate  { get; set; }
    public string? Description { get; set; }
    public int Quantity { get; set; }
    public int Cumulative { get; set; }
    public double ValueMinimum { get; set; }
    public double ValueMaximum { get; set; }
    public string? Image{ get; set; } // Ruta de la imagen en wwwroot
    
    [NotMapped]
    public IFormFile? ImagenReal { get; set; } // Archivo de imagen

        
}