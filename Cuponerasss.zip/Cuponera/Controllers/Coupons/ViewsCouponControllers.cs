using Coupons.Models;
using Microsoft.AspNetCore.Mvc;

public class ViewsCouponController : ControllerBase
{
  private readonly ICouponRepository _couponRepository;

  public ViewsCouponController(ICouponRepository couponRepository)
  {
    _couponRepository = couponRepository;
  }
  public IEnumerable<Coupon> GetCoupons()
  {
    return _couponRepository.GetAll();
  }
}