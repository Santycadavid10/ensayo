using Microsoft.EntityFrameworkCore;
using Coupons.Models;


namespace LUEGOPAGO.Data;
public class LuegoPagoContext : DbContext
{
    public LuegoPagoContext(DbContextOptions<LuegoPagoContext> options) : base(options)
    {
    }
    public DbSet<Coupon> Coupons{ get; set; }
     }

